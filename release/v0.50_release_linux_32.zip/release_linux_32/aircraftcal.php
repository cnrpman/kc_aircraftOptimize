<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<title>空母自动配装preview</title>
		<link rel="stylesheet" href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css">
		<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
		<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
		<style type="text/css">
			body {
				padding-top: 20px;
			}
			strong 
			{
				color:#0044AA;
			}
		</style>
	</head>
	<body>
<!--header-->
	<div class="container">
	<div class="col-sm-6" style="padding-top: 100px">
  <h3><b>空母自动配装preview_2</b></h3></br></br>
	<div class="well">一个根据空母和现有舰载机计算出<strong>满足指定制空值</strong>的<strong>火力优化配置</strong>的工具<br>
	<br>	
	<a href="http://www.rpman.net/aircraft-calc-manual/"><strong>点击这里进入:使用说明</strong><br></a>
	<br>
	<b>20150329</b><br>
	加入攻击机最小格的条件，以供考虑战损的需要.
	加入手动强制罚站选项，选中空母左上方的复选框可以使该空母只能装备战斗机（同时仍支持自动罚站）.
	</div>
	
	</div>
  <div class="col-sm-4 col-sm-offset-2">
	<img src="KanColleDougaKagaThumbnail.png" alt="Kaga">
	</div>
	</div>
<!--body-->
	
	<form method="post" action = "ret.php" role="form">
	<div class="container">
		<div class="row">
		<div class="col-sm-4">
				</br>
				</br>
				<strong>目标制空值:</strong></br></br>
				<input type="text" name="ad" size = 4 class="form-control"/></br>
				</br>
				<strong>装载舰攻/舰爆的最低格子大小(默认为不限制):</strong></br></br>
				<input type="text" name="las" size = 4 class="form-control"/></br>
				</br>
				<strong>开幕系数(默认为0.05):</strong></br></br>
				<input type="text" name="op" size = 4 class="form-control"/></br>
				</br>
				<strong>空母:</strong></br></br>
				<!--<input type="text" name="cnum" size = 4/></br>
				</br>-->
				<?php
				$cvtxt = 'C_DAT.txt';
				$cvchn = 'C_TRANS.txt';
				$cvtxtcontent = file_get_contents($cvtxt);
				$cvchncontent = file_get_contents($cvchn);
				$cvarray = explode("\r\n", $cvtxtcontent);
				$cvchnarray = explode("\r\n", $cvchncontent);
				
				for($i=0; $i<4;$i++){
					echo "<input type=\"checkbox\" name=\"ifo" . $i. "\"/>";
					echo "<div class=\"input-group input-group-sm\">";
					echo "<select name = \"cv".$i."\" class=\"form-control\">";
					echo "<option value=\"null\"> -- </option>";
					for($j=0; $j*3<count($cvarray); $j++){
						$cvattri=explode(' ',$cvarray[$j*3+1]);
						switch($cvattri[0]){
							case 'CV': $color=	'#FFFAEE';break;
							case 'CVL' : $color= '#FFFCFB';break;
						}
						echo "<option value=\"".$cvarray[$j*3]."\" style = \"background-color:" . $color."\">".$cvchnarray[$j]."</option>";
					}
					echo "</select>";
					echo "<span class=\"input-group-addon\">";
					for($j=0; $j<4; $j++){
						echo "<input type=\"checkbox\" checked=\"checked\" name=\"cv" . $i . "box" . $j . "\"/>";
					}
					echo "</span>";
					echo "</div>";//<!-- /input-group -->
					echo "</br>";
				}
				?>
				</br>
				</br>
				</br>
				<input type="submit" value="submit" class="btn btn-primary btn-lg btn-block"/>
				</br>
				</br>
			</div>
			<div class="col-sm-5 col-sm-offset-3">
				</br>
				</br>
				<strong>可用舰载机x数量:</strong></br></br>
				
				<?php			
				$ptxt = 'P_DAT.txt';
				$pchn = 'P_TRANS.txt';
				$ptxtcontent = file_get_contents($ptxt);
				$pchncontent = file_get_contents($pchn);
				$parray = explode("\r\n", $ptxtcontent);
				$pchnarray = explode("\r\n", $pchncontent);
				
				for($i=0; $i<15;$i++){
					echo "<div class=\"row\">
					<div class=\"col-xs-8\">";
					echo "<select name = \"plane".$i."\" class=\"form-control\">";
					echo "<option value=\"null\"> -- </option>";
					for($j=0; $j*3<count($parray); $j++){
						$pattri=explode(' ',$parray[$j*3+1]);
						switch($pattri[0]){
							case 'Fighter': $color=	'#BBFFEE';break;
							case 'Bomber' : $color= '#FFDDEE';break;
							case 'TorpedoAttacker' : $color= '#CCEEFF';break;
						}
						echo "<option value=\"".$parray[$j*3]."\" style = \"background-color:" . $color . "\">".$pchnarray[$j]."</option>";
					}
					echo "</select>
					</div>";
					echo "<div class=\"col-xs-4\">
					<div class=\"input-group input-group-sm\">
					<span class=\"input-group-addon\">
					x
					</span>
					<input type=\"text\" class=\"form-control\" size=\"2\" name=\"plane".$i."num\"/>
					</div>
					</div>
					</div>
					</br>";
				}
				?>
			</div>
			</div>
		</div>	
		</div>
		</form>
	</body>

</html>
