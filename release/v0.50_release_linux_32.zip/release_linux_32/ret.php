<html>
	<head>
	<meta charset="UTF-8"> 
	<title>result</title>
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" href="http://apps.bdimg.com/libs/bootstrap/3.2.0/css/bootstrap.min.css">
	</head>
	<body>
	<div class="container">
		<div class="talbe-responsive">
		<?php
		//assemble module
		$arr = (empty($_POST['ad']) ? '0' :  $_POST['ad']). ' ';
		$arr .= (empty($_POST['op']) ? '0.05' :  $_POST['op']). ' ';
		$arr .= (empty($_POST['au']) ? '0.01' :  $_POST['au']). ' ';
		$arr .= (empty($_POST['las']) ? '0' :  $_POST['las']). ' ';

		$cvn = 0;
		for($i=0; $i<4;$i++){
			if($_POST["cv" . $i]!="null"){
				$usedcv[$cvn]=$_POST["cv" . $i];
				$cvn++;
			}
		}
		$arr .= $cvn . ' ';

		for($i=0; $i<4;$i++){
			$cv = $_POST["cv" . $i];
			if($cv!="null"){
				$arr .= $cv . ' ';
				$square=1;
				$number=0;
				for($j=3;$j>=0;$j--){
					if($_POST["cv" . $i . "box" . $j]=="on")
						$number+=$square;
					$square<<=1;
				}
				$arr.= $number . ' ' . ($_POST['ifo' . $i]=="on"?'1':'0') . ' ';
			}
		}


		$pn = 0;
		for($i=0; $i<15;$i++){
			if($_POST["plane".$i]!="null"){
				$pn++;
			}
		}
		$arr .= $pn . ' ';

		for($i=0; $i < 15; $i++){
			$plane = $_POST["plane".$i];
			if($plane!="null"){
				$arr .= $plane . ' ';
				$arr .= (empty($_POST["plane".$i."num"]) ? '1': $_POST["plane".$i."num"] ). ' ';
			}
		}

			echo "<b>Querry: </b>" . $arr . "</br>";

			$command = './aircraftcal ' . escapeshellcmd($arr);
			$bylines;
			exec($command, $bylines);
			
			//translate module
			
			$cvtxt = 'C_DAT.txt';
			$cvchntxt = 'C_TRANS.txt';
			$cvtxtcontent = file_get_contents($cvtxt);
			$cvchncontent = file_get_contents($cvchntxt);
			$cvarray = explode("\r\n", $cvtxtcontent);
			$cvchnarray = explode("\r\n", $cvchncontent);
			for($i=0; $i<count($cvchnarray);$i++){
				$cvtranslate[$cvarray[$i*3]] = $cvchnarray[$i];
				$cvdata[$cvarray[$i*3]] = $cvarray[$i*3 + 1];
			}
			
			$ptxt = 'P_DAT.txt';
			$pchntxt = 'P_TRANS.txt';
			$ptxtcontent = file_get_contents($ptxt);
			$pchncontent = file_get_contents($pchntxt);
			$parray = explode("\r\n", $ptxtcontent);
			$pchnarray = explode("\r\n", $pchncontent);
			for($i=0; $i<count($pchnarray);$i++){
				$ptranslate[$parray[$i*3]] = $pchnarray[$i];
			}
			$ptranslate[' - '] = '&nbsp-&nbsp';
			
		//	print_r($cvdata);
			
			//display module
			echo "<b>Return:</b> " . $bylines[0] . "</br>";
			echo "<table class=\"table table-striped table-bordered\">";
			echo "<thead><tr><th>空母</th><th>壹</th><th>贰</th><th>叁</th><th>肆</th></tr></thead>";
			echo "<tbody>";
			for($i=1;$i<count($bylines);$i++){
				if($i <= count($usedcv)){
					echo "<tr>";
					echo "<th>" . $cvtranslate[$usedcv[$i-1]] . "</th>";
					$byrows=explode("|",$bylines[$i]);
					$datarray = explode(' ',$cvdata[$usedcv[$i-1]]);
					for($j=0;$j<count($byrows)-1;$j++){
						echo "<td>" . $ptranslate[$byrows[$j]] . '(' . $datarray[$j+2] . ")</td>";
					}
					echo "</tr>";
				}
			}
			echo "</tbody>";
			echo "</table>";
		?>
		</div>
	</div>
</body>
</html>